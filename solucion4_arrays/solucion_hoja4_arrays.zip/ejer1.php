<!DOCTYPE html>
<html lang="es">
<head>
    <title>Ejercicio 1. Hoja 4</title>
    <meta charset="utf-8">
</head>
<body>
  <?php
    function dividir ($x)
    {
      $r=array("cero","uno","dos","tres","cuatro","cinco","seis","siete","ocho","nueve","diez","once");
      $resto=$x % 12;
      return $r[$resto];
    }

    if ($_REQUEST)
    {
      echo "<h1>Resultado</h1>";
      echo "El número introducido ha sido el ",$_REQUEST['numero']," y el resto de su división por 12 es ",dividir($_REQUEST['numero']),".";
    }
  ?>
  <h1>Formulario</h1>
  <form action="ejer1.php" method="get">
    <b>DAME UN NÚMERO:</b>
    <input type="number" name="numero" min="0"/> <br/>
    <input type="submit" value="Enviar"/>
    <input type="reset" value="Borrar"/>
  </form>
</body>
</html>