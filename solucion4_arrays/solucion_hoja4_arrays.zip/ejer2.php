﻿<!DOCTYPE html>
<html lang="es">
<head>
	<title>Ejercicio 2. Hoja 4</title>
	<meta charset="utf-8">
</head>
<body>
	<?php
		if ($_REQUEST)
		{
			$cantidad=$_REQUEST['euros'];
			$valor=array(500,200,100,50,20,10,5,2,1);
			echo "<h1>ALGORITMO DESGLOSE MONEDAS</h1> ";
			echo "Cantidad total de euros pedidos a desglosar es: $cantidad<br/>";
			for($i=0;$i<count($valor);$i++)
			{
				$unidades=intval($cantidad/$valor[$i]);		//También se puede utilizar la función floor()
				$cantidad=$cantidad%$valor[$i];				//Se almacena en la variable $cantidad el resto de la división para el siguiente paso del bucle
				echo "Nº de unidades de $valor[$i] euros es $unidades <br/>";
			}
			echo "<br/> <a href='ejer2.php'>Volver a pedir nuevo desglose</a>";
		}
		else
		{
			echo
			"
				<h1>EJERCICIO DESGLOSE DE MONEDAS</h1>
				<form action='ejer2.php' method='GET'>
					Introduce cantidad de euros a desglosar:
					<input type='number' name='euros'  min='1' required/></br></br>
					<input type='submit' value='Enviar'/>
				</form>
			";
		}
	?>
</body>
</html>
