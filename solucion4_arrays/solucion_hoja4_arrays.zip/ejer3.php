﻿<!DOCTYPE html>
<html lang="es">
<head>
	<title>Ejercicio 3. Hoja 4</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="estilosimple.css"/>
</head>
<body>
	<?php
		echo"<h1>OBTENCIÓN DE LA TEMPERATURA MEDIA DE LA SEMANA</h1>";
		$v=$_REQUEST["v"];		//La variable $v se convierte en un array con los datos almacenados en el array $_REQUEST
								//Otra opcion sería construir el array en PHP con: $v=array($_REQUEST[Lunes],$_REQUEST[Martes],...)
		$suma=0;
		for($i=0;$i<count($v);$i++)
		{
			$suma+=$v[$i];
		}
		$media=$suma/count($v);
		echo "La temperatura media de la semana es: ",round($media,2)," (calculada con bucle for)<br>";		//round($variable,2) redondea a dos decimales
		echo "También se puede usar la función array_sum() y dividir por el número de elementos count(). El resultado es: ",round(array_sum($v)/count($v),2);
	?>
</body>
</html>